<form action="" method="post">
<table border="1">
<tr><td>Name:</td><td><input type="text" name="name" title="Enter name" /></td></tr>

<tr><td><input type="submit" value="save" /></td></tr>
</table>
</form>
<br />






