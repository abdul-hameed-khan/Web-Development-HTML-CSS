<form action="index.php?action=save_details" method="post">
<table border="1">
<tr><td>Name:</td><td><input type="text" name="name" title="Enter name" /></td></tr>
<tr><td>Password:</td><td><input type="password" name="pass" title="Enter password" /></td></tr>
<tr><td><input type="submit" value="save" /></td></tr>
</table>
</form>
<br />



















<a  href="index.php?action=view_details">View Details</a>
<a href="index.php?controller=user&action=delete">Delete Details</a>

