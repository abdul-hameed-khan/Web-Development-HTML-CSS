<?php
include("model/model.php");
class controller
{//start of the class
public $mymodel;
public function __construct()
{
$this->mymodel = new model();
}

public function invoke()
{//public function invoke
$page = "";
if(isset($_GET['action']))
		{
			$page= $_GET['action'];
		}
		
		



if($page == "save_details")
{
$name = $_POST["name"];//getting form elements using post method
$pass = $_POST["pass"];//getting form elements using post method

$res = $this->mymodel->save($name,$pass);

}
else if($page == "view_details"){

include("view/view.php");

}

else if($page=="delete")
{
	
}

else
{
include ("view/save.php");
}

}
}//end of class
?>