<?php
include ("controller/controller.php");
$obj =new controller();


$obj ->invoke();
echo"AB";
?>
