<?php
class model
{//start of the class
public $mydb;
public function __construct ()
{//start
$this->mydb = new mysqli("localhost","root","","bcs5");
if(mysqli_connect_errno())
{
echo "error in connection";
}
}


public function save($name,$pass)
{

$query_insert_date = "INSERT INTO `reg` (`name`, `pass`) VALUES ('$name','$pass')";


if($result_s = $this->mydb->query($query_insert_date))
{
    echo "Inserted";
}
else
{
echo "Error: ".$this->mydb->error ;
}
}

}//end of class
?>